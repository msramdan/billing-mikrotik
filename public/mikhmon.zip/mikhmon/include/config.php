<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<sawitskylink','mikhmon>|>q5KpoaVibmVjcWo=');



$data['Sawitskylink'] = array ('1'=>'Sawitskylink!103.122.65.234:83','Sawitskylink@|@sawitskylink','Sawitskylink#|#q5KpoaVibmVjcWo=','Sawitskylink%sawitskylink','Sawitskylink^sawitskylink.net','Sawitskylink&Rp','Sawitskylink*10','Sawitskylink(1','Sawitskylink)','Sawitskylink=10','Sawitskylink@!@disable');